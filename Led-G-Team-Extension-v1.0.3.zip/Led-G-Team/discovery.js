'use strict';
const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const CONTACT_HINT = /contact|about|team|support|help|company|reach|impressum|customer|service|location|staff|people/i;
const SOCIAL_HOSTS = { facebook:['facebook.com','fb.com'], instagram:['instagram.com'], linkedin:['linkedin.com'], youtube:['youtube.com','youtu.be'], x:['x.com','twitter.com'], tiktok:['tiktok.com'], whatsapp:['wa.me','whatsapp.com'] };
function socialLinks(links) { const found={}; for (const link of links) { try { const u=new URL(link.href); for (const [name,hosts] of Object.entries(SOCIAL_HOSTS)) if(hosts.some(h=>u.hostname===h||u.hostname.endsWith('.'+h))) { if(!found[name]) found[name]=u.href; } } catch {} } return found; }
function cleanUrl(raw) { try { const u = new URL(raw); u.hash = ''; ['utm_source','utm_medium','utm_campaign','fbclid','gclid'].forEach(k => u.searchParams.delete(k)); return u.href; } catch { return raw; } }
function validEmail(value) { return value.length < 120 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && !/(example\.(com|org)|test\.com)$/i.test(value) && !/\.(png|jpe?g|gif|svg|webp|css|js|woff2?)$/i.test(value); }
function parsePage(html, url) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script,style,svg,noscript').forEach(e => e.remove());
  const text = (doc.body?.textContent || '').slice(0, 220000);
  const raw = html.slice(0, 450000);
  const emails = new Set([...(text.match(EMAIL_RE) || []), ...(raw.match(EMAIL_RE) || [])].map(x => x.toLowerCase()).filter(validEmail));
  for (const a of doc.querySelectorAll('a[href^="mailto:"]')) { const e = a.getAttribute('href').slice(7).split('?')[0].toLowerCase(); if (validEmail(e)) emails.add(e); }
  for (const m of text.matchAll(/([a-z0-9._%+-]+)\s*(?:\[at\]|\(at\)|\s+at\s+)\s*([a-z0-9.-]+)\s*(?:\[dot\]|\(dot\)|\s+dot\s+)\s*([a-z]{2,})/gi)) { const e = `${m[1]}@${m[2]}.${m[3]}`.toLowerCase(); if (validEmail(e)) emails.add(e); }
  const phoneCandidates = text.match(/(?:\+?\d[\d\s().-]{6,}\d)/g) || [];
  const phones = [...new Set(phoneCandidates.map(x => x.trim().replace(/\s+/g, ' ')).filter(x => { const d=x.replace(/\D/g,''); return d.length>=8 && d.length<=15 && !/^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}$/.test(x) && !/^\d{5,6}$/.test(d); }))];
  const links = [...doc.querySelectorAll('a[href]')].map(a => { try { return { href: new URL(a.getAttribute('href'), url).href, label: (a.textContent || '').trim().slice(0,80) }; } catch { return null; } }).filter(Boolean);
  const contacts = links.filter(x => { try { return new URL(x.href).origin === new URL(url).origin && CONTACT_HINT.test(x.href + ' ' + x.label) && /^https?:/i.test(x.href); } catch { return false; } });
  return { emails:[...emails], phones, contacts, links, socials:socialLinks(links) };
}
async function crawlWebsite(startUrl, initial, maxPages, onProgress, signal) {
  const base = new URL(startUrl); const seen = new Set([cleanUrl(startUrl)]), queued = new Set();
  const emails = new Map(), phones = new Map();
  const socials = {...(initial.socials||{})};
  const addFound = (parsed, source) => {
    parsed.emails.forEach(email => { const old=emails.get(email)||[]; if(!old.includes(source)) old.push(source); emails.set(email,old); });
    parsed.phones.forEach(phone => { const old=phones.get(phone)||[]; if(!old.includes(source)) old.push(source); phones.set(phone,old); });
  };
  addFound(initial, startUrl);
  const queue=[];
  const enqueue=(href)=>{ try { const u=new URL(href,startUrl); const normalized=cleanUrl(u.href); if(!/^https?:$/.test(u.protocol)||u.hostname.replace(/^www\./,'')!==base.hostname.replace(/^www\./,'')||seen.has(normalized)||queued.has(normalized)||/\.(pdf|zip|png|jpe?g|gif|webp|mp4|css|js)(\?|$)/i.test(u.href))return; queued.add(normalized); queue.push(normalized); } catch {} };
  initial.contacts.forEach(x=>enqueue(x.href));
  for (const p of ['/contact','/contact-us','/about','/about-us','/support','/help','/team','/our-team','/company','/pages/contact']) enqueue(base.origin+p);
  for (const a of (initial.links||[])) if(CONTACT_HINT.test(a.href+' '+a.label)) enqueue(a.href);
  let attempted=0;
  while(queue.length && attempted < Math.max(1, Math.min(15, maxPages-1))) {
    if(signal?.aborted) throw new DOMException('Scan cancelled','AbortError');
    const url=queue.shift(); if(seen.has(url)) continue; seen.add(url); attempted++;
    onProgress?.({attempted,limit:maxPages,emails:emails.size,phones:phones.size,url});
    const controller=new AbortController(); const abort=()=>controller.abort(); signal?.addEventListener('abort',abort,{once:true}); const timer=setTimeout(()=>controller.abort(),9000);
    try {
      const response=await fetch(url,{signal:controller.signal,credentials:'omit',redirect:'follow'});
      if(!response.ok || !/text\/html/i.test(response.headers.get('content-type')||'')) continue;
      const finalUrl=new URL(response.url); if(finalUrl.hostname.replace(/^www\./,'')!==base.hostname.replace(/^www\./,'')) continue;
      const html=(await response.text()).slice(0,600000); const parsed=parsePage(html,response.url); addFound(parsed,response.url); Object.assign(socials, Object.fromEntries(Object.entries(parsed.socials||{}).filter(([k])=>!socials[k])));
      parsed.contacts.forEach(x=>enqueue(x.href));
    } catch(error) { if(signal?.aborted) throw error; }
    finally { clearTimeout(timer); signal?.removeEventListener('abort',abort); }
  }
  return {emails:[...emails].map(([value,sources])=>({value,sources})),phones:[...phones].map(([value,sources])=>({value,sources})),socials,pagesScanned:attempted+1};
}
