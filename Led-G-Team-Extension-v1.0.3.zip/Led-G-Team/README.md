# Led G Team Extension 1.0.2

A new, standalone Chrome Manifest V3 extension for collecting publicly displayed business contact details.

## Install
1. Extract this ZIP file.
2. Open `chrome://extensions` in Chrome.
3. Enable Developer mode.
4. Select **Load unpacked** and choose the extracted `Led-G-Team` folder.
5. Open a public website and click the Led G Team extension icon. It opens in Chrome Side Panel.
6. Click **Collect Website Leads** and grant access to the website when Chrome asks.

## Features
- New Led G Team name and supplied gold/navy logo.
- Navy blue and gold interface.
- Balanced website scan: current page plus relevant internal contact/about/support/team pages, bounded by the 15-page default (configurable).
- Injected page scanner (`scan.js`) for visible page text, mailto/tel links, HTML email strings and common visibly published obfuscated email formats.
- Phone candidate detection with basic length/date/postcode filtering. Results are candidates and should be verified.
- Manual email, phone and website entry.
- Facebook/public social page current-tab scan. Login walls and inaccessible/dynamic content are not bypassed.
- Individual checkboxes, group selection, Select All, individual Copy and Copy Selected for Sheets.
- Copy Selected exports one tab-separated row: selected emails in column A, selected phone numbers in column B, website URL in column C. Multiple emails/numbers in a cell are separated with semicolons.
- Last five collection sessions with Website, Facebook/Social or Manual source labels.
- Settings for scan depth, deduplication, automatic selection and history.

## Limitations
- Website crawling depends on the site's public availability, Chrome host permission, CORS, server behavior and rate limits. It cannot guarantee finding every contact detail.
- The scan is bounded, not a full web-wide crawler. It does not bypass login pages, CAPTCHA, paywalls or access controls.
- Phone-number filtering is heuristic; some non-phone number strings may still appear and some valid numbers may be missed.
- Google Sheets is not directly connected. Use Copy Selected for Sheets, then paste into the desired row.
- History stores the latest five collection sessions in Chrome local storage.

## Privacy
The extension processes public page content in the browser and stores history/settings locally in Chrome storage. It does not send collected details to a remote server.


Version 1.0.2 updates: website URL is normalized to the root domain only (for example, example.com; without protocol, path, query or hash); a single discovered email/phone is preselected automatically while multiple results require manual selection; added reduced-motion-aware premium loading, result-reveal and tab-transition animations.


## Version 1.0.3 updates
- Added compact, clickable social-platform logo shortcuts (Facebook, Instagram, LinkedIn, YouTube, X, TikTok and WhatsApp) discovered from the scanned website pages.
- Added creator credit: Made by Siam HR.
- Kept the selected-data copy workflow accessible with a sticky bottom action area to reduce scrolling.
