'use strict';
(() => {
  const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
  const CONTACT_HINT = /contact|about|team|support|help|company|reach|impressum|customer|service|location|staff|people/i;
  const url = location.href;
  const emails = new Set();
  const phones = new Set();
  const addEmail = value => {
    const email = String(value || '').trim().replace(/^mailto:/i, '').split('?')[0].toLowerCase();
    if (email.length < 120 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !/(example\.(com|org)|test\.com)$/i.test(email) && !/\.(png|jpe?g|gif|svg|webp|css|js|woff2?)$/i.test(email)) emails.add(email);
  };
  const addPhone = value => {
    const phone = String(value || '').trim().replace(/\s+/g, ' ');
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 8 || digits.length > 15) return;
    if (/^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}$/.test(phone) || /^\d{5,6}$/.test(digits)) return;
    if (!/[+()\-\s]/.test(phone) && digits.length < 10) return;
    phones.add(phone);
  };

  const bodyText = document.body?.innerText || document.body?.textContent || '';
  const html = document.documentElement?.outerHTML || '';
  for (const match of bodyText.match(EMAIL_RE) || []) addEmail(match);
  for (const match of html.match(EMAIL_RE) || []) addEmail(match);
  document.querySelectorAll('a[href^="mailto:"]').forEach(a => addEmail(a.getAttribute('href')));
  document.querySelectorAll('a[href^="tel:"]').forEach(a => addPhone(a.getAttribute('href').slice(4)));
  for (const match of bodyText.matchAll(/([a-z0-9._%+-]+)\s*(?:\[at\]|\(at\)|\s+at\s+)\s*([a-z0-9.-]+)\s*(?:\[dot\]|\(dot\)|\s+dot\s+)\s*([a-z]{2,})/gi)) addEmail(`${match[1]}@${match[2]}.${match[3]}`);
  for (const match of bodyText.match(/(?:\+?\d[\d\s().-]{6,}\d)/g) || []) addPhone(match);

  const links = [...document.querySelectorAll('a[href]')].map(a => {
    try { return { href: new URL(a.getAttribute('href'), url).href, label: (a.innerText || a.textContent || '').trim().slice(0, 100) }; }
    catch { return null; }
  }).filter(Boolean);
  const origin = location.origin;
  const contacts = links.filter(item => {
    try { return new URL(item.href).origin === origin && CONTACT_HINT.test(`${item.href} ${item.label}`) && /^https?:/i.test(item.href); }
    catch { return false; }
  });

  const socialHosts={facebook:['facebook.com','fb.com'],instagram:['instagram.com'],linkedin:['linkedin.com'],youtube:['youtube.com','youtu.be'],x:['x.com','twitter.com'],tiktok:['tiktok.com'],whatsapp:['wa.me','whatsapp.com']};
  const socials={}; for(const item of links){try{const u=new URL(item.href);for(const [name,hosts] of Object.entries(socialHosts))if(hosts.some(h=>u.hostname===h||u.hostname.endsWith('.'+h))&&!socials[name])socials[name]=u.href;}catch{}}
  return { url, emails: [...emails], phones: [...phones], links, contacts, socials };
})();
